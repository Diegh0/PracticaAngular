import { Component } from '@angular/core';
import { ServiciosHttpService } from '../Servicios/servicios-http.service';
import { Cliente } from '../Modelos/cliente';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent {

  constructor(
    private servicioClientes:ServiciosHttpService
  ){}
  clientes!:Cliente[]
  ngOnInit(){
    this.servicioClientes.getClientes().subscribe(datos=>this.clientes=datos)
  }

}
