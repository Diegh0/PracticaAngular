export interface Cliente {
    id: number, 
    nombre: string,
    cargo: string
}